function f2c(value){
    console.log(value)
}